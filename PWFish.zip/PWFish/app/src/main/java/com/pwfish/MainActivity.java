package com.pwfish;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.text.InputType;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.LinkedHashMap;
import java.util.Map;

public class MainActivity extends Activity {

    private static final int REQ_CAPTURE = 1;
    private final Map<String, EditText> fields = new LinkedHashMap<>();
    private LinearLayout root;
    private TextView status;
    private String pendingMode = "run";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        ScrollView scroll = new ScrollView(this);
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        int pad = dp(16);
        root.setPadding(pad, pad, pad, pad);
        scroll.addView(root);
        setContentView(scroll);

        status = new TextView(this);
        status.setTextSize(16);
        root.addView(status);

        addButton("1. Buka pengaturan Aksesibilitas", v ->
                startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        addButton("2. Mulai PROBE (simpan 15 screenshot)", v -> start("probe"));
        addButton("3. Mulai AUTO FISHING", v -> start("run"));
        addButton("STOP", v -> {
            startService(new Intent(this, CaptureService.class).setAction(CaptureService.ACTION_STOP));
            toast("Dihentikan");
        });

        TextView head = new TextView(this);
        head.setText("\nPengaturan (koordinat layar landscape)");
        head.setTextSize(18);
        root.addView(head);

        SharedPreferences p = Config.prefs(this);
        for (String[] k : Config.KEYS) {
            TextView label = new TextView(this);
            label.setText(k[2]);
            root.addView(label);

            EditText et = new EditText(this);
            et.setSingleLine(true);
            et.setText(Config.str(p, k[0]));
            if (!k[0].endsWith("color")) {
                et.setInputType(InputType.TYPE_CLASS_NUMBER);
            }
            root.addView(et);
            fields.put(k[0], et);
        }
        addButton("Simpan pengaturan", v -> {
            save();
            toast("Tersimpan");
        });

        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 2);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        boolean acc = FishAccessibility.instance != null;
        status.setText("Aksesibilitas: " + (acc ? "AKTIF" : "belum aktif")
                + "\nStatus: " + (CaptureService.running ? "berjalan" : "berhenti")
                + "\nScreenshot probe tersimpan di folder Pictures/PWFish\n");
    }

    private void start(String mode) {
        save();
        if ("run".equals(mode) && FishAccessibility.instance == null) {
            toast("Aktifkan aksesibilitas PW Fish dulu (tombol 1)");
            return;
        }
        if (CaptureService.running) {
            toast("Sudah berjalan. Tekan STOP dulu.");
            return;
        }
        pendingMode = mode;
        MediaProjectionManager mpm = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
        startActivityForResult(mpm.createScreenCaptureIntent(), REQ_CAPTURE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQ_CAPTURE) return;
        if (resultCode != RESULT_OK || data == null) {
            toast("Izin rekam layar ditolak");
            return;
        }
        Intent i = new Intent(this, CaptureService.class)
                .putExtra(CaptureService.EXTRA_CODE, resultCode)
                .putExtra(CaptureService.EXTRA_DATA, data)
                .putExtra(CaptureService.EXTRA_MODE, pendingMode);
        startForegroundService(i);
        toast("Berjalan dalam 3 detik. Buka Pixel Worlds sekarang.");
    }

    private void save() {
        SharedPreferences.Editor e = Config.prefs(this).edit();
        for (Map.Entry<String, EditText> f : fields.entrySet()) {
            e.putString(f.getKey(), f.getValue().getText().toString().trim());
        }
        e.apply();
    }

    private void addButton(String text, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setOnClickListener(l);
        root.addView(b);
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }
}
