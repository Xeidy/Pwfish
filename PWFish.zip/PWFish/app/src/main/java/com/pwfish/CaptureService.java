package com.pwfish;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.graphics.Bitmap;
import android.graphics.PixelFormat;
import android.graphics.drawable.Icon;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.provider.MediaStore;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.WindowManager;

import java.io.OutputStream;
import java.nio.ByteBuffer;

/**
 * Merekam layar (hanya di memori, tidak disimpan kecuali mode probe),
 * membaca warna piksel, lalu menyuruh FishAccessibility mengetuk layar.
 */
public class CaptureService extends Service {

    public static final String ACTION_STOP = "com.pwfish.STOP";
    public static final String EXTRA_CODE = "code";
    public static final String EXTRA_DATA = "data";
    public static final String EXTRA_MODE = "mode";

    private static final String TAG = "PWFish";
    private static final String CHANNEL = "pwfish";
    private static final int NOTIF_ID = 1;

    public static volatile boolean running = false;

    private MediaProjection projection;
    private VirtualDisplay display;
    private ImageReader reader;
    private Thread worker;
    private int width, height;

    // frame yang sedang dibaca (hanya diakses dari thread worker)
    private Image cur;
    private ByteBuffer buf;
    private int rowStride, pixelStride;

    // pengaturan
    private int castX, castY, tapX, tapY;
    private int sX, sY, sW, sH, sColor, sTol;
    private int bX, bY, bW, bH, bcX, bcY, barColor, targetColor, fishColor, tol;
    private boolean holdRight;
    private int deadzone, pressMs, strikeTimeout, afterCatch, maxFish;

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null || ACTION_STOP.equals(intent.getAction())) {
            running = false;
            if (worker == null) shutdown();
            return START_NOT_STICKY;
        }

        createChannel();
        startForeground(NOTIF_ID, buildNotification("Menyiapkan..."),
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);

        int code = intent.getIntExtra(EXTRA_CODE, 0);
        Intent data = intent.getParcelableExtra(EXTRA_DATA);
        final String mode = intent.getStringExtra(EXTRA_MODE);
        if (data == null) {
            shutdown();
            return START_NOT_STICKY;
        }

        loadConfig();

        MediaProjectionManager mpm = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
        projection = mpm.getMediaProjection(code, data);
        if (projection == null) {
            shutdown();
            return START_NOT_STICKY;
        }
        projection.registerCallback(new MediaProjection.Callback() {
            @Override
            public void onStop() {
                running = false;
            }
        }, new Handler(Looper.getMainLooper()));

        DisplayMetrics dm = new DisplayMetrics();
        WindowManager wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        wm.getDefaultDisplay().getRealMetrics(dm);
        // Game dimainkan landscape: sisi panjang = lebar
        width = Math.max(dm.widthPixels, dm.heightPixels);
        height = Math.min(dm.widthPixels, dm.heightPixels);

        reader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 3);
        display = projection.createVirtualDisplay("pwfish", width, height, dm.densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader.getSurface(), null, null);

        running = true;
        worker = new Thread(() -> {
            try {
                sleep(3000); // waktu untuk pindah ke game
                if ("probe".equals(mode)) probeLoop();
                else fishLoop();
            } catch (Exception e) {
                Log.e(TAG, "Error", e);
            } finally {
                running = false;
                releaseFrame();
                new Handler(Looper.getMainLooper()).post(this::shutdown);
            }
        }, "pwfish-worker");
        worker.start();
        return START_NOT_STICKY;
    }

    // ------------------------------------------------------------ logika

    private void probeLoop() {
        for (int i = 1; i <= 15 && running; i++) {
            if (refresh()) saveFrame("pw_probe_" + System.currentTimeMillis() + "_" + i + ".png");
            setStatus("Probe: screenshot " + i + "/15");
            sleep(2000);
        }
    }

    private void fishLoop() {
        int caught = 0;
        setStatus("Auto fishing berjalan");
        while (running && (maxFish == 0 || caught < maxFish)) {
            if (FishAccessibility.instance == null) {
                setStatus("Aksesibilitas mati, berhenti");
                break;
            }
            tap(castX, castY);               // lempar kail
            sleep(800);
            if (!running) break;
            if (!waitStrike()) continue;     // tidak ada strike -> lempar ulang
            sleep(200);
            playMinigame();
            if (!running) break;
            caught++;
            setStatus("Ikan tertangkap: " + caught);
            sleep(afterCatch);
            tap(tapX, tapY);                 // tutup popup hasil (jika ada)
            sleep(500);
        }
    }

    private boolean waitStrike() {
        long start = System.currentTimeMillis();
        while (running && System.currentTimeMillis() - start < strikeTimeout) {
            if (refresh()) {
                if (barVisible()) return true;
                if (regionHasColor(sX, sY, sW, sH, sColor, sTol)) {
                    tap(tapX, tapY);
                    return true;
                }
            }
            sleep(30);
        }
        return false;
    }

    private void playMinigame() {
        int lost = 0;
        while (running && lost < 15) {
            if (!refresh() || !barVisible()) {
                lost++;
                sleep(40);
                continue;
            }
            lost = 0;
            float t = avgX(targetColor);
            float f = avgX(fishColor);
            if (t < 0 || f < 0) {
                sleep(20);
                continue;
            }
            boolean needRight = f - t > deadzone;
            boolean needLeft = t - f > deadzone;
            boolean hold = holdRight ? needRight : needLeft;
            FishAccessibility acc = FishAccessibility.instance;
            if (hold && acc != null) acc.press(tapX, tapY, pressMs);
            sleep(pressMs);
        }
    }

    // ------------------------------------------------------------ baca layar

    /** Ambil frame terbaru. Kalau layar tidak berubah, frame lama tetap dipakai. */
    private boolean refresh() {
        Image next = null;
        try {
            next = reader.acquireLatestImage();
        } catch (IllegalStateException ignored) {
        }
        if (next != null) {
            if (cur != null) cur.close();
            cur = next;
            Image.Plane plane = cur.getPlanes()[0];
            buf = plane.getBuffer();
            rowStride = plane.getRowStride();
            pixelStride = plane.getPixelStride();
        }
        return cur != null;
    }

    private void releaseFrame() {
        if (cur != null) {
            cur.close();
            cur = null;
        }
    }

    /** Warna piksel sebagai 0xRRGGBB, atau -1 jika di luar layar. */
    private int pixel(int x, int y) {
        if (x < 0 || y < 0 || x >= width || y >= height) return -1;
        int i = y * rowStride + x * pixelStride;
        int r = buf.get(i) & 0xFF;
        int g = buf.get(i + 1) & 0xFF;
        int b = buf.get(i + 2) & 0xFF;
        return (r << 16) | (g << 8) | b;
    }

    private static boolean similar(int c, int target, int t) {
        if (c < 0) return false;
        return Math.abs(((c >> 16) & 0xFF) - ((target >> 16) & 0xFF)) <= t
                && Math.abs(((c >> 8) & 0xFF) - ((target >> 8) & 0xFF)) <= t
                && Math.abs((c & 0xFF) - (target & 0xFF)) <= t;
    }

    private boolean barVisible() {
        return similar(pixel(bcX, bcY), barColor, tol);
    }

    private boolean regionHasColor(int x, int y, int w, int h, int color, int t) {
        for (int yy = y; yy < y + h; yy += 2)
            for (int xx = x; xx < x + w; xx += 2)
                if (similar(pixel(xx, yy), color, t)) return true;
        return false;
    }

    /** Rata-rata posisi X piksel berwarna color di area bar, atau -1. */
    private float avgX(int color) {
        long sum = 0;
        int n = 0;
        for (int yy = bY; yy < bY + bH; yy += 2)
            for (int xx = bX; xx < bX + bW; xx += 2)
                if (similar(pixel(xx, yy), color, tol)) {
                    sum += xx;
                    n++;
                }
        return n == 0 ? -1f : (float) sum / n;
    }

    private void saveFrame(String name) {
        try {
            buf.rewind();
            Bitmap full = Bitmap.createBitmap(rowStride / pixelStride, height, Bitmap.Config.ARGB_8888);
            full.copyPixelsFromBuffer(buf);
            buf.rewind();
            Bitmap bmp = Bitmap.createBitmap(full, 0, 0, width, height);

            ContentValues v = new ContentValues();
            v.put(MediaStore.Images.Media.DISPLAY_NAME, name);
            v.put(MediaStore.Images.Media.MIME_TYPE, "image/png");
            v.put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/PWFish");
            ContentResolver cr = getContentResolver();
            Uri uri = cr.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v);
            if (uri != null) {
                try (OutputStream os = cr.openOutputStream(uri)) {
                    if (os != null) bmp.compress(Bitmap.CompressFormat.PNG, 100, os);
                }
            }
            if (bmp != full) bmp.recycle();
            full.recycle();
        } catch (Exception e) {
            Log.e(TAG, "Gagal simpan screenshot", e);
        }
    }

    // ------------------------------------------------------------ bantu

    private void tap(int x, int y) {
        FishAccessibility acc = FishAccessibility.instance;
        if (acc != null) acc.press(x, y, 50);
    }

    private static void sleep(long ms) {
        try {
            Thread.sleep(ms);
        } catch (InterruptedException ignored) {
        }
    }

    private void loadConfig() {
        SharedPreferences p = Config.prefs(this);
        castX = Config.i(p, "cast_x");
        castY = Config.i(p, "cast_y");
        tapX = Config.i(p, "tap_x");
        tapY = Config.i(p, "tap_y");
        sX = Config.i(p, "strike_x");
        sY = Config.i(p, "strike_y");
        sW = Config.i(p, "strike_w");
        sH = Config.i(p, "strike_h");
        sColor = Config.color(p, "strike_color");
        sTol = Config.i(p, "strike_tol");
        bX = Config.i(p, "bar_x");
        bY = Config.i(p, "bar_y");
        bW = Config.i(p, "bar_w");
        bH = Config.i(p, "bar_h");
        bcX = Config.i(p, "barcheck_x");
        bcY = Config.i(p, "barcheck_y");
        barColor = Config.color(p, "bar_color");
        targetColor = Config.color(p, "target_color");
        fishColor = Config.color(p, "fish_color");
        tol = Config.i(p, "tol");
        holdRight = Config.i(p, "hold_right") != 0;
        deadzone = Config.i(p, "deadzone");
        pressMs = Math.max(10, Config.i(p, "press_ms"));
        strikeTimeout = Config.i(p, "strike_timeout");
        afterCatch = Config.i(p, "after_catch");
        maxFish = Config.i(p, "max_fish");
    }

    private void createChannel() {
        NotificationChannel ch = new NotificationChannel(CHANNEL, "PW Fish", NotificationManager.IMPORTANCE_LOW);
        getSystemService(NotificationManager.class).createNotificationChannel(ch);
    }

    private Notification buildNotification(String text) {
        PendingIntent stop = PendingIntent.getService(this, 0,
                new Intent(this, CaptureService.class).setAction(ACTION_STOP),
                PendingIntent.FLAG_IMMUTABLE);
        return new Notification.Builder(this, CHANNEL)
                .setSmallIcon(android.R.drawable.ic_media_play)
                .setContentTitle("PW Fish")
                .setContentText(text)
                .setOngoing(true)
                .addAction(new Notification.Action.Builder(
                        Icon.createWithResource(this, android.R.drawable.ic_media_pause),
                        "STOP", stop).build())
                .build();
    }

    private void setStatus(String text) {
        getSystemService(NotificationManager.class).notify(NOTIF_ID, buildNotification(text));
    }

    private void shutdown() {
        running = false;
        try {
            if (display != null) display.release();
        } catch (Exception ignored) {
        }
        try {
            if (projection != null) projection.stop();
        } catch (Exception ignored) {
        }
        try {
            if (reader != null) reader.close();
        } catch (Exception ignored) {
        }
        display = null;
        projection = null;
        reader = null;
        worker = null;
        stopForeground(STOP_FOREGROUND_REMOVE);
        stopSelf();
    }

    @Override
    public void onDestroy() {
        running = false;
        super.onDestroy();
    }
}
