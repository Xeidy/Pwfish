package com.pwfish;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;

/** Semua pengaturan yang bisa diubah dari layar utama aplikasi. */
public final class Config {
    private Config() {}

    /** {kunci, nilai bawaan, label} */
    public static final String[][] KEYS = {
            {"cast_x", "1250", "Titik lempar kail X"},
            {"cast_y", "820", "Titik lempar kail Y"},
            {"tap_x", "1250", "Titik tap/tahan mini-game X"},
            {"tap_y", "820", "Titik tap/tahan mini-game Y"},

            {"strike_x", "1100", "Area strike X"},
            {"strike_y", "560", "Area strike Y"},
            {"strike_w", "300", "Area strike lebar"},
            {"strike_h", "120", "Area strike tinggi"},
            {"strike_color", "#FFFFFF", "Warna tanda strike"},
            {"strike_tol", "20", "Toleransi warna strike"},

            {"bar_x", "650", "Bar FISH ON X"},
            {"bar_y", "160", "Bar FISH ON Y"},
            {"bar_w", "1250", "Bar FISH ON lebar"},
            {"bar_h", "12", "Bar FISH ON tinggi"},
            {"barcheck_x", "700", "Titik cek bar tampil X"},
            {"barcheck_y", "166", "Titik cek bar tampil Y"},
            {"bar_color", "#2E7FD8", "Warna bar (biru)"},
            {"target_color", "#3CE03C", "Warna zona TARGET (hijau)"},
            {"fish_color", "#1F6F2A", "Warna ikon ikan"},
            {"tol", "25", "Toleransi warna bar"},

            {"hold_right", "1", "Tahan = target ke kanan? (1 ya / 0 tidak)"},
            {"deadzone", "15", "Deadzone (piksel)"},
            {"press_ms", "60", "Lama satu tekan (ms)"},
            {"strike_timeout", "30000", "Batas tunggu strike (ms)"},
            {"after_catch", "1500", "Jeda setelah dapat ikan (ms)"},
            {"max_fish", "0", "Batas ikan (0 = tanpa batas)"},
    };

    public static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences("pwfish", Context.MODE_PRIVATE);
    }

    public static String def(String key) {
        for (String[] k : KEYS) if (k[0].equals(key)) return k[1];
        return "0";
    }

    public static String str(SharedPreferences p, String key) {
        String v = p.getString(key, def(key));
        return v == null ? def(key) : v.trim();
    }

    public static int i(SharedPreferences p, String key) {
        try {
            return Integer.parseInt(str(p, key));
        } catch (NumberFormatException e) {
            return Integer.parseInt(def(key));
        }
    }

    /** Warna "#RRGGBB" -> int 0xRRGGBB */
    public static int color(SharedPreferences p, String key) {
        try {
            return Color.parseColor(str(p, key)) & 0xFFFFFF;
        } catch (IllegalArgumentException e) {
            return Color.parseColor(def(key)) & 0xFFFFFF;
        }
    }
}
